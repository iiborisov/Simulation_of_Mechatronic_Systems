%% Paremeters

%% Geometry
AB=5; %cm
x_AD=2*AB; %cm
y_AD=0; %cm
BC=2.5*AB; %cm
CD=2.5*AB; %cm
radius=1.1; %cm
L=2.1; %cm

%% Links' settings  
Link_AB=[AB 2 2];
Link_BC=[BC 2 2];
Link_CD=[CD 2 2];
Link_CF=[CD 2 2];

density=8000;
colour=[0.6 0.6 1.0];
colour_pin=[0.2 0.2 1.0];

%% Analysis
% l_1=AB*0.01;
% l_2=BC*0.01;
% l_3=CD*0.01;
% l_4=x_AD*0.01;
% l_5=CD*0.01;
% q_1=simout.theta.data;
% q_2_S=simout.theta_2.data;
% dd=l_1^2+l_4^2-2*l_1*l_4*cos(q_1);
% d=sqrt(dd);
% q_2=asin(l_4.*sin(q_1)./d)+acos((d.^2+l_2^2-l_5^2)./(2.*d*l_2));
% x_F=-l_1*cos(pi+q_1)-l_2*cos(pi+q_1+q_2_S)-l_3*cos(pi+q_1+q_2_S);
% y_F=l_1*sin(pi-q_1)+l_2*sin(pi-q_1-q_2_S)+l_3*sin(pi-q_1-q_2_S);
% plot(x_F, y_F, 'linewidth',1);
