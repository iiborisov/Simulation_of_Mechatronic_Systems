function asA = as(A)
% Syntax
% y = antisym(A);
% 
% Description
% Returns an anti-symmetric matrix. This function is equal to:
% 
% y = (A - transpose(A))/2;
% 
% Examples
% A = [1,2;3,4];
% 
% Y = antisym(A);
% 
% Limitations
% A must be a square matrix. Y and A must be of the same size.

asA = (A - transpose(A))/2;
end