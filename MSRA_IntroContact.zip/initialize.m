% Introduction to Contact Modeling -- Initialization script
% Copyright 2017 The MathWorks, Inc.

% Add necessary folders to the MATLAB path
addpath(genpath('Examples'),genpath('Libraries'));